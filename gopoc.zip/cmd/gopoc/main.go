package main

import (
	"bufio"
	"flag"
	"fmt"
	"io"
	"log"
	"os"
	"path/filepath"
	"strings"
	"time"

	"github.com/gopoc/sdk"
)

// ScanResult 扫描结果结构
type ScanResult struct {
	Target     string
	POCFile    string
	POCName    string
	CVEID      string
	Level      string
	Success    bool
	Error      string
	Timestamp  string
}

func main() {
	var (
		targetFile = flag.String("f", "", "目标 URL 列表文件（每行一个 URL）")
		singleTarget = flag.String("t", "", "单个目标 URL")
		singlePOC   = flag.String("poc", "", "单个 POC 文件")
		multiplePOCs = flag.String("pocs", "", "多个 POC 文件（逗号分隔）或目录路径")
		outputFile = flag.String("o", "", "保存结果到文件")
		verbose    = flag.Bool("v", false, "详细输出")
	)

	flag.Parse()

	// 验证参数：必须指定目标（-f 或 -t）和 POC（-poc 或 -pocs）
	if *targetFile == "" && *singleTarget == "" {
		fmt.Println("错误: 必须指定目标 URL")
		fmt.Println("  使用 -t <URL> 指定单个目标")
		fmt.Println("  或使用 -f <file> 指定目标列表文件")
		flag.Usage()
		os.Exit(1)
	}

	if *singlePOC == "" && *multiplePOCs == "" {
		fmt.Println("错误: 必须指定 POC 文件")
		fmt.Println("  使用 -poc <file> 指定单个 POC 文件")
		fmt.Println("  或使用 -pocs <files> 指定多个 POC 文件（逗号分隔）或目录")
		flag.Usage()
		os.Exit(1)
	}

	// 收集目标 URL
	var targets []string
	if *singleTarget != "" {
		targets = []string{*singleTarget}
	} else if *targetFile != "" {
		var err error
		targets, err = readTargetsFromFile(*targetFile)
		if err != nil {
			log.Fatalf("读取目标文件失败: %v", err)
		}
		if len(targets) == 0 {
			log.Fatalf("目标文件为空或格式错误")
		}
		if *verbose {
			fmt.Printf("从文件读取到 %d 个目标\n", len(targets))
		}
	}

	// 收集 POC 文件
	var pocFiles []string
	if *singlePOC != "" {
		pocFiles = []string{*singlePOC}
	} else if *multiplePOCs != "" {
		var err error
		pocFiles, err = expandPOCPaths(*multiplePOCs)
		if err != nil {
			log.Fatalf("解析 POC 路径失败: %v", err)
		}
		if len(pocFiles) == 0 {
			log.Fatalf("未找到 POC 文件")
		}
		if *verbose {
			fmt.Printf("找到 %d 个 POC 文件\n", len(pocFiles))
		}
	}

	// 准备输出文件
	var outputWriter io.Writer = os.Stdout
	var outputFileHandle *os.File
	var results []ScanResult

	if *outputFile != "" {
		var err error
		outputFileHandle, err = os.Create(*outputFile)
		if err != nil {
			log.Fatalf("创建输出文件失败: %v", err)
		}
		defer outputFileHandle.Close()
		// 只在详细模式下同时输出到文件（用于日志）
		// 但结果会单独写入文件（简洁格式）
		if *verbose {
			outputWriter = io.MultiWriter(os.Stdout, outputFileHandle)
		}
	}

	// 执行扫描
	totalTests := len(targets) * len(pocFiles)
	currentTest := 0
	successCount := 0
	failCount := 0

	if *verbose {
		fmt.Fprintf(outputWriter, "\n开始扫描: %d 个目标 × %d 个 POC = %d 次测试\n\n", 
			len(targets), len(pocFiles), totalTests)
	}

	for _, target := range targets {
		for _, pocFile := range pocFiles {
			currentTest++
			result := ScanResult{
				Target:    target,
				POCFile:   pocFile,
				Timestamp: time.Now().Format("2006-01-02 15:04:05"),
			}

			if *verbose {
				fmt.Fprintf(outputWriter, "[%d/%d] 测试目标: %s | POC: %s\n", 
					currentTest, totalTests, target, filepath.Base(pocFile))
			}

			// 加载 POC 配置
			config, err := sdk.LoadConfig(pocFile)
			if err != nil {
				result.Error = fmt.Sprintf("加载POC失败: %v", err)
				log.Printf("加载 POC 失败 %s: %v", pocFile, err)
				failCount++
				results = append(results, result)
				continue
			}

			result.POCName = config.Name
			result.CVEID = config.CVEID
			result.Level = config.Level

			if *verbose {
				fmt.Fprintf(outputWriter, "  POC: %s (CVE: %s, 等级: %s)\n", 
					config.Name, config.CVEID, config.Level)
			}

			// 创建执行引擎
			engine := sdk.NewEngine(config, target)
			engine.SetVerbose(*verbose)

			// 执行 POC
			success, err := engine.Execute()
			if err != nil {
				result.Error = fmt.Sprintf("执行失败: %v", err)
				if *verbose {
					log.Printf("  执行失败: %v\n", err)
				}
				failCount++
				results = append(results, result)
				continue
			}

			result.Success = success

			// 输出结果到终端
			if success {
				fmt.Printf("✓ [成功] 目标: %s | POC: %s (%s)\n", 
					target, config.Name, config.Level)
				if *verbose && *outputFile != "" {
					fmt.Fprintf(outputFileHandle, "✓ [成功] 目标: %s | POC: %s (%s)\n", 
						target, config.Name, config.Level)
				}
				successCount++
			} else {
				if *verbose {
					fmt.Printf("✗ [失败] 目标: %s | POC: %s\n", target, config.Name)
					if *outputFile != "" {
						fmt.Fprintf(outputFileHandle, "✗ [失败] 目标: %s | POC: %s\n", target, config.Name)
					}
				}
				failCount++
			}

			results = append(results, result)

			if *verbose && currentTest < totalTests {
				fmt.Fprintf(outputWriter, "\n")
			}
		}
	}

	// 输出总结
	summary := fmt.Sprintf("%s\n扫描完成: 成功 %d, 失败 %d, 总计 %d\n",
		strings.Repeat("=", 50), successCount, failCount, totalTests)
	fmt.Print(summary)

	// 如果指定了输出文件，写入简洁的结果
	if *outputFile != "" {
		writeResultsToFile(outputFileHandle, results, successCount, failCount, totalTests)
		if *verbose {
			fmt.Printf("\n结果已保存到: %s\n", *outputFile)
		} else {
			fmt.Printf("结果已保存到: %s\n", *outputFile)
		}
	}

	if successCount > 0 {
		os.Exit(0)
	} else {
		os.Exit(1)
	}
}

// writeResultsToFile 将结果写入文件
func writeResultsToFile(file *os.File, results []ScanResult, successCount, failCount, totalTests int) {
	// 写入成功的结果
	for _, r := range results {
		if r.Success {
			file.WriteString(fmt.Sprintf("[成功] %s | %s | %s\n", r.Target, r.POCName, r.POCFile))
		}
	}

	// 写入失败的结果
	for _, r := range results {
		if !r.Success {
			file.WriteString(fmt.Sprintf("[失败] %s | %s | %s\n", r.Target, r.POCName, r.POCFile))
		}
	}
}

// readTargetsFromFile 从文件读取目标 URL 列表
func readTargetsFromFile(filename string) ([]string, error) {
	file, err := os.Open(filename)
	if err != nil {
		return nil, err
	}
	defer file.Close()

	var targets []string
	scanner := bufio.NewScanner(file)
	for scanner.Scan() {
		line := strings.TrimSpace(scanner.Text())
		// 跳过空行和注释
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		targets = append(targets, line)
	}

	if err := scanner.Err(); err != nil {
		return nil, err
	}

	return targets, nil
}

// expandPOCPaths 展开 POC 路径（支持逗号分隔的文件列表或目录）
func expandPOCPaths(paths string) ([]string, error) {
	var pocFiles []string

	// 分割逗号分隔的路径
	parts := strings.Split(paths, ",")
	
	for _, part := range parts {
		part = strings.TrimSpace(part)
		if part == "" {
			continue
		}

		// 检查是否是目录
		info, err := os.Stat(part)
		if err != nil {
			// 如果路径不存在，可能是单个文件路径（可能不存在）
			// 先尝试作为文件处理
			if strings.HasSuffix(part, ".yaml") || strings.HasSuffix(part, ".yml") {
				pocFiles = append(pocFiles, part)
			}
			continue
		}

		if info.IsDir() {
			// 是目录，扫描所有 .yaml 和 .yml 文件
			err := filepath.Walk(part, func(path string, info os.FileInfo, err error) error {
				if err != nil {
					return err
				}
				if !info.IsDir() {
					ext := strings.ToLower(filepath.Ext(path))
					if ext == ".yaml" || ext == ".yml" {
						pocFiles = append(pocFiles, path)
					}
				}
				return nil
			})
			if err != nil {
				return nil, fmt.Errorf("扫描目录失败 %s: %w", part, err)
			}
		} else {
			// 是文件
			pocFiles = append(pocFiles, part)
		}
	}

	return pocFiles, nil
}

