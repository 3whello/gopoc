package main

import (
	"fmt"
	"log"

	"github.com/gopoc/sdk"
)

func main() {
	// 加载 POC 配置
	config, err := sdk.LoadConfig("../test.yaml")
	if err != nil {
		log.Fatalf("加载配置失败: %v", err)
	}

	fmt.Printf("加载 POC: %s\n", config.Name)
	fmt.Printf("CVE ID: %s\n", config.CVEID)
	fmt.Printf("安全等级: %s\n", config.Level)
	fmt.Println()

	// 创建执行引擎（替换为实际的目标 URL）
	baseURL := "http://localhost:8080"
	engine := sdk.NewEngine(config, baseURL)

	// 执行 POC
	fmt.Printf("开始执行 POC，目标: %s\n", baseURL)
	fmt.Println()

	success, err := engine.Execute()
	if err != nil {
		log.Fatalf("执行失败: %v", err)
	}

	// 显示详细结果
	fmt.Println("执行结果:")
	results := engine.GetAllRuleResults()
	for ruleName, result := range results {
		status := "✗ 失败"
		if result {
			status = "✓ 成功"
		}
		fmt.Printf("  %s: %s\n", ruleName, status)
	}

	fmt.Println()
	if success {
		fmt.Println("✓ POC 验证成功！发现安全漏洞。")
	} else {
		fmt.Println("✗ POC 验证失败，目标可能不存在该漏洞。")
	}
}

